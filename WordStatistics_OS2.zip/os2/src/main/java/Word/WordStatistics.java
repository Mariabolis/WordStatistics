/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Word;

/**
 *
 * @author Maria
 */
public class WordStatistics {


    private int wordCount;
    private String longestWord = "";
    private String shortestWord = "";
    private int isCount;
    private int areCount;
    private int youCount;
    private String fileContent = "";

    public int getWordCount() {
        return wordCount;
    }

    public String getLongestWord() {
        return longestWord;
    }

    public String getShortestWord() {
        return shortestWord;
    }

    public int getIsCount() {
        return isCount;
    }

    public int getAreCount() {
        return areCount;
    }

    public int getYouCount() {
        return youCount;
    }

    public String getFileContent() {
        return fileContent;
    }

    public void setFileContent(String fileContent) {
        this.fileContent = fileContent;
    }

    public void incrementWordCount(int count) {
        wordCount += count;
    }

    public void updateLongestShortestWord(String word) {
        if (word.length() > longestWord.length()) {
            longestWord = word;
        }

        if (shortestWord.isEmpty() || word.length() < shortestWord.length()) {
            shortestWord = word;
        }
    }

    public void updateWordOccurrences(String word) {
        if (word.equalsIgnoreCase("is")) {
            isCount++;
        } else if (word.equalsIgnoreCase("are")) {
            areCount++;
        } else if (word.equalsIgnoreCase("you")) {
            youCount++;
        }
    }
}


