package Word;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class WordStatisticsProcessor {

    private final JTable outputTable;
    private final ExecutorService executorService;

    public WordStatisticsProcessor(JTable outputTable) {
        this.outputTable = outputTable;
        this.executorService = Executors.newFixedThreadPool(5);
    }

     public void processFilesAsync(File fileOrDirectory) {
        DefaultTableModel tableModel = (DefaultTableModel) outputTable.getModel();
        tableModel.setRowCount(0);

        ExecutorService executorService = Executors.newFixedThreadPool(5);

        if (fileOrDirectory.isFile()) {
            executorService.submit(() -> processFile(fileOrDirectory));
        } else if (fileOrDirectory.isDirectory()) {
            executorService.submit(() -> processFilesInDirectory(fileOrDirectory));
        }

        executorService.shutdown();

        try {
            executorService.awaitTermination(60, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // ... (existing code)

    private void processFilesInDirectory(File directory) {
        File[] files = directory.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    executorService.submit(() -> processFile(file));
                } else if (file.isDirectory()) {
                    processFilesInDirectory(file);
                }
            }
        }
    }
    private void processFile(File file) {
        WordStatistics wordStatistics = processTextFile(file);
        displayWordStatistics(file.getName(), wordStatistics);
    }

    private WordStatistics processTextFile(File file) {
        WordStatistics wordStatistics = new WordStatistics();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder contentBuilder = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                contentBuilder.append(line).append(System.lineSeparator());
                processLine(line, wordStatistics);
            }

            wordStatistics.setFileContent(contentBuilder.toString());

        } catch (IOException e) {
            // Handle IOException if needed
            e.printStackTrace();
        }

        return wordStatistics;
    }

    private void processLine(String line, WordStatistics wordStatistics) {
        // Split the line into words (you might need a more sophisticated word extraction logic)
        String[] words = line.split("\\s+");

        for (String word : words) {
            // Process each word and update the WordStatistics
            wordStatistics.incrementWordCount(1);
            wordStatistics.updateLongestShortestWord(word);
            wordStatistics.updateWordOccurrences(word);
        }
    }

    private void displayWordStatistics(String fileName, final WordStatistics wordStatistics) {
        SwingUtilities.invokeLater(() -> {
            DefaultTableModel tableModel = (DefaultTableModel) outputTable.getModel();
            tableModel.addRow(new Object[]{
                    fileName,
                    wordStatistics.getWordCount(),
                    wordStatistics.getLongestWord(),
                    wordStatistics.getShortestWord(),
                    wordStatistics.getIsCount(),
                    wordStatistics.getAreCount(),
                    wordStatistics.getYouCount()
            });
        });
    }
}
